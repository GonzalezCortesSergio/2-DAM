from main import *

print(poner_palabras_mayuscula("hola como estás"))
print(poner_palabras_mayuscula("albaricoque"))
print(poner_palabras_mayuscula("lleva la tarara un vestido verde lleno de volantes y de cascabeles"))