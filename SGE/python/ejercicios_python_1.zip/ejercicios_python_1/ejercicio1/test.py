from main import *

print("Primer texto: ")
print(transformar_texto_morse("Hola qué tal estás"))

print(" ")
print(" ")

print("Segundo texto: ")
print(transformar_texto_morse("Esto es otra prueba para ver qué tal funciona la función de pasar texto natural a código morse"))

print(" ")
print(" ")

print("Primer morse: ")
print(transformar_morse_texto("... --- ..."))

print(" ")
print(" ")
print("Segundo morse: ")
print(transformar_morse_texto(".. .-.. --- ...- . -.-- --- ..-"))

