from main import *

array_1 = ["a", 1, "c", "d", "e"]
array_2 = ["2", 1, "a", "b", "9"]

print(elementos_comunes(array_1, array_2, False))
print(elementos_comunes(array_1, array_2, True))