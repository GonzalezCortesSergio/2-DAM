from main import *

acciones = ["jump", "run", "run", "run", "jump"]
pista = "__|_|"

print(evaluar_atleta(acciones, pista))