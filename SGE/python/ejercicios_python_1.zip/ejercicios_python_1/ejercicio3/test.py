from main import *

print(transformar_cadenas("Aljofifa", "Altramuz"))
print(transformar_cadenas("abcd", "efg"))