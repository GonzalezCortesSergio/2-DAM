from main import *

print(comprobar_expresion("{[a * (c + d)] - 5}"))
print(comprobar_expresion("{a * (c + d)] - 5}"))
